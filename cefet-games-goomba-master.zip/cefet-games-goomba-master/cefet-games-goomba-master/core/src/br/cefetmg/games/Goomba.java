package br.cefetmg.games;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

/**
 *
 * @author fegemo
 */

public class Goomba {
    
    private int x=50,y=50;
    private int[] velocidade = {0,0};
    private Sprite textura_jogador = new Sprite (new Texture("goomba.png"));
    
    public Goomba(Texture spriteSheet) {
        textura_jogador.setPosition(x, y);
        // cria as regiões para cada quadro de animação
        // cria e configura as animações (andar para esquerda, direita, 
        // cima, baixo)
    }
    
    public static void update() {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
//            velocidade.x = -1;
            
        }
        // verifica se a seta ← está pressionada
        //  if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
        //    animacaoCorrente = animacaoEsquerda;
        //   velocidade.x = -1;
        //}
        
        
    }
    
    public void render(SpriteBatch batch) {
        
    }
    
    public void setPosition () {
        
    }
}